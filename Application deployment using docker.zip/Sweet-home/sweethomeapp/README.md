# Sweet-Home

&nbsp;

## Deployment

To deploy this project

- Install docker - [Ubuntu](https://docs.docker.com/engine/install/ubuntu/)

and run
```bash
  docker compose up
```
